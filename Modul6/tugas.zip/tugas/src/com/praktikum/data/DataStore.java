package com.praktikum.data;

public class DataStore {
}
