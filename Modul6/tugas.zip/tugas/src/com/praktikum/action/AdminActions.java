package com.praktikum.action;
public interface AdminActions {
    void ManageItems();
    void ManageUsers();
}
