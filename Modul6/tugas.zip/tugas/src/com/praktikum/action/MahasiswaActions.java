package com.praktikum.action;

public interface MahasiswaActions {
    void ReportItem();
    void ViewReportItem();
}
